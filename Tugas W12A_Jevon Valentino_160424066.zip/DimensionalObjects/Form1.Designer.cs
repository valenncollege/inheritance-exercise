﻿namespace Tugas_W12A_Jevon_Valentino_160424066
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxZ = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxX = new System.Windows.Forms.TextBox();
            this.textBoxZ2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBoxInputObject = new System.Windows.Forms.GroupBox();
            this.buttonSaveObject = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxY = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxY2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxX2 = new System.Windows.Forms.TextBox();
            this.textBoxZ1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxY1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButton3D = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxX1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.buttonCalculateDistance = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonDisplay = new System.Windows.Forms.Button();
            this.radioButton2D = new System.Windows.Forms.RadioButton();
            this.listBoxInfo = new System.Windows.Forms.ListBox();
            this.groupBoxCalculateDistance = new System.Windows.Forms.GroupBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.groupBoxInputObject.SuspendLayout();
            this.groupBoxCalculateDistance.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(7, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(96, 15);
            this.label10.TabIndex = 40;
            this.label10.Text = "Input Object  :";
            // 
            // textBoxZ
            // 
            this.textBoxZ.Location = new System.Drawing.Point(256, 26);
            this.textBoxZ.Name = "textBoxZ";
            this.textBoxZ.Size = new System.Drawing.Size(39, 20);
            this.textBoxZ.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(101, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "X :";
            // 
            // textBoxX
            // 
            this.textBoxX.Location = new System.Drawing.Point(125, 25);
            this.textBoxX.Name = "textBoxX";
            this.textBoxX.Size = new System.Drawing.Size(41, 20);
            this.textBoxX.TabIndex = 1;
            // 
            // textBoxZ2
            // 
            this.textBoxZ2.Location = new System.Drawing.Point(264, 58);
            this.textBoxZ2.Name = "textBoxZ2";
            this.textBoxZ2.Size = new System.Drawing.Size(35, 20);
            this.textBoxZ2.TabIndex = 11;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(73, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(32, 15);
            this.label12.TabIndex = 6;
            this.label12.Text = "X2 :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(151, 61);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 15);
            this.label13.TabIndex = 8;
            this.label13.Text = "Y2 :";
            // 
            // groupBoxInputObject
            // 
            this.groupBoxInputObject.Controls.Add(this.label10);
            this.groupBoxInputObject.Controls.Add(this.textBoxZ);
            this.groupBoxInputObject.Controls.Add(this.label2);
            this.groupBoxInputObject.Controls.Add(this.buttonSaveObject);
            this.groupBoxInputObject.Controls.Add(this.label3);
            this.groupBoxInputObject.Controls.Add(this.textBoxY);
            this.groupBoxInputObject.Controls.Add(this.label4);
            this.groupBoxInputObject.Controls.Add(this.textBoxX);
            this.groupBoxInputObject.Location = new System.Drawing.Point(25, 53);
            this.groupBoxInputObject.Name = "groupBoxInputObject";
            this.groupBoxInputObject.Size = new System.Drawing.Size(315, 92);
            this.groupBoxInputObject.TabIndex = 11;
            this.groupBoxInputObject.TabStop = false;
            this.groupBoxInputObject.Text = "Input Object";
            // 
            // buttonSaveObject
            // 
            this.buttonSaveObject.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSaveObject.Location = new System.Drawing.Point(121, 53);
            this.buttonSaveObject.Name = "buttonSaveObject";
            this.buttonSaveObject.Size = new System.Drawing.Size(142, 25);
            this.buttonSaveObject.TabIndex = 6;
            this.buttonSaveObject.Text = "Save Object";
            this.buttonSaveObject.UseVisualStyleBackColor = true;
            this.buttonSaveObject.Click += new System.EventHandler(this.buttonSaveObject_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(169, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Y :";
            // 
            // textBoxY
            // 
            this.textBoxY.Location = new System.Drawing.Point(194, 25);
            this.textBoxY.Name = "textBoxY";
            this.textBoxY.Size = new System.Drawing.Size(36, 20);
            this.textBoxY.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(236, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Z :";
            // 
            // textBoxY2
            // 
            this.textBoxY2.Location = new System.Drawing.Point(182, 59);
            this.textBoxY2.Name = "textBoxY2";
            this.textBoxY2.Size = new System.Drawing.Size(38, 20);
            this.textBoxY2.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(232, 61);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 15);
            this.label14.TabIndex = 10;
            this.label14.Text = "Z2 :";
            // 
            // textBoxX2
            // 
            this.textBoxX2.Location = new System.Drawing.Point(106, 59);
            this.textBoxX2.Name = "textBoxX2";
            this.textBoxX2.Size = new System.Drawing.Size(38, 20);
            this.textBoxX2.TabIndex = 7;
            // 
            // textBoxZ1
            // 
            this.textBoxZ1.Location = new System.Drawing.Point(264, 25);
            this.textBoxZ1.Name = "textBoxZ1";
            this.textBoxZ1.Size = new System.Drawing.Size(35, 20);
            this.textBoxZ1.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(73, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "X1 :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(151, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "Y1 :";
            // 
            // textBoxY1
            // 
            this.textBoxY1.Location = new System.Drawing.Point(182, 27);
            this.textBoxY1.Name = "textBoxY1";
            this.textBoxY1.Size = new System.Drawing.Size(38, 20);
            this.textBoxY1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 15);
            this.label1.TabIndex = 17;
            this.label1.Text = "Select Coordinate :";
            // 
            // radioButton3D
            // 
            this.radioButton3D.AutoSize = true;
            this.radioButton3D.Checked = true;
            this.radioButton3D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3D.Location = new System.Drawing.Point(201, 22);
            this.radioButton3D.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton3D.Name = "radioButton3D";
            this.radioButton3D.Size = new System.Drawing.Size(43, 19);
            this.radioButton3D.TabIndex = 10;
            this.radioButton3D.TabStop = true;
            this.radioButton3D.Text = "3D";
            this.radioButton3D.UseVisualStyleBackColor = true;
            this.radioButton3D.CheckedChanged += new System.EventHandler(this.radioButton3D_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(232, 29);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 15);
            this.label11.TabIndex = 4;
            this.label11.Text = "Z1 :";
            // 
            // textBoxX1
            // 
            this.textBoxX1.Location = new System.Drawing.Point(106, 27);
            this.textBoxX1.Name = "textBoxX1";
            this.textBoxX1.Size = new System.Drawing.Size(38, 20);
            this.textBoxX1.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 15);
            this.label5.TabIndex = 41;
            this.label5.Text = "Object 2 :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(7, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 15);
            this.label9.TabIndex = 39;
            this.label9.Text = "Object 1 :";
            // 
            // buttonCalculateDistance
            // 
            this.buttonCalculateDistance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalculateDistance.Location = new System.Drawing.Point(103, 88);
            this.buttonCalculateDistance.Name = "buttonCalculateDistance";
            this.buttonCalculateDistance.Size = new System.Drawing.Size(157, 29);
            this.buttonCalculateDistance.TabIndex = 12;
            this.buttonCalculateDistance.Text = "Calculate Distance";
            this.buttonCalculateDistance.UseVisualStyleBackColor = true;
            this.buttonCalculateDistance.Click += new System.EventHandler(this.buttonCalculateDistance_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(515, 282);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(77, 26);
            this.buttonClear.TabIndex = 14;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonDisplay
            // 
            this.buttonDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDisplay.Location = new System.Drawing.Point(353, 282);
            this.buttonDisplay.Name = "buttonDisplay";
            this.buttonDisplay.Size = new System.Drawing.Size(159, 26);
            this.buttonDisplay.TabIndex = 13;
            this.buttonDisplay.Text = "Display All Objects";
            this.buttonDisplay.UseVisualStyleBackColor = true;
            this.buttonDisplay.Click += new System.EventHandler(this.buttonDisplay_Click);
            // 
            // radioButton2D
            // 
            this.radioButton2D.AutoSize = true;
            this.radioButton2D.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2D.Location = new System.Drawing.Point(153, 22);
            this.radioButton2D.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButton2D.Name = "radioButton2D";
            this.radioButton2D.Size = new System.Drawing.Size(43, 19);
            this.radioButton2D.TabIndex = 9;
            this.radioButton2D.Text = "2D";
            this.radioButton2D.UseVisualStyleBackColor = true;
            this.radioButton2D.CheckedChanged += new System.EventHandler(this.radioButton2D_CheckedChanged);
            // 
            // listBoxInfo
            // 
            this.listBoxInfo.FormattingEnabled = true;
            this.listBoxInfo.Location = new System.Drawing.Point(353, 29);
            this.listBoxInfo.Name = "listBoxInfo";
            this.listBoxInfo.Size = new System.Drawing.Size(311, 251);
            this.listBoxInfo.TabIndex = 15;
            // 
            // groupBoxCalculateDistance
            // 
            this.groupBoxCalculateDistance.Controls.Add(this.textBoxZ2);
            this.groupBoxCalculateDistance.Controls.Add(this.label12);
            this.groupBoxCalculateDistance.Controls.Add(this.label13);
            this.groupBoxCalculateDistance.Controls.Add(this.textBoxY2);
            this.groupBoxCalculateDistance.Controls.Add(this.label14);
            this.groupBoxCalculateDistance.Controls.Add(this.textBoxX2);
            this.groupBoxCalculateDistance.Controls.Add(this.textBoxZ1);
            this.groupBoxCalculateDistance.Controls.Add(this.label7);
            this.groupBoxCalculateDistance.Controls.Add(this.label8);
            this.groupBoxCalculateDistance.Controls.Add(this.textBoxY1);
            this.groupBoxCalculateDistance.Controls.Add(this.label11);
            this.groupBoxCalculateDistance.Controls.Add(this.textBoxX1);
            this.groupBoxCalculateDistance.Controls.Add(this.label5);
            this.groupBoxCalculateDistance.Controls.Add(this.label9);
            this.groupBoxCalculateDistance.Controls.Add(this.buttonCalculateDistance);
            this.groupBoxCalculateDistance.Location = new System.Drawing.Point(21, 150);
            this.groupBoxCalculateDistance.Name = "groupBoxCalculateDistance";
            this.groupBoxCalculateDistance.Size = new System.Drawing.Size(319, 131);
            this.groupBoxCalculateDistance.TabIndex = 12;
            this.groupBoxCalculateDistance.TabStop = false;
            this.groupBoxCalculateDistance.Text = "Calculate Distance";
            // 
            // buttonExit
            // 
            this.buttonExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(591, 282);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(74, 26);
            this.buttonExit.TabIndex = 16;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 343);
            this.Controls.Add(this.groupBoxInputObject);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton3D);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonDisplay);
            this.Controls.Add(this.radioButton2D);
            this.Controls.Add(this.listBoxInfo);
            this.Controls.Add(this.groupBoxCalculateDistance);
            this.Controls.Add(this.buttonExit);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBoxInputObject.ResumeLayout(false);
            this.groupBoxInputObject.PerformLayout();
            this.groupBoxCalculateDistance.ResumeLayout(false);
            this.groupBoxCalculateDistance.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxZ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxX;
        private System.Windows.Forms.TextBox textBoxZ2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBoxInputObject;
        private System.Windows.Forms.Button buttonSaveObject;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxY;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxY2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxX2;
        private System.Windows.Forms.TextBox textBoxZ1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxY1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton3D;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxX1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonCalculateDistance;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonDisplay;
        private System.Windows.Forms.RadioButton radioButton2D;
        private System.Windows.Forms.ListBox listBoxInfo;
        private System.Windows.Forms.GroupBox groupBoxCalculateDistance;
        private System.Windows.Forms.Button buttonExit;
    }
}

